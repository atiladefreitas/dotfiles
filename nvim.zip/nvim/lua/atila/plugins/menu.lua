return {
	{
		"NvChad/volt",
		lazy = true,
	},
	{
		"NvChad/menu",
		lazy = true,
		config = function() end,
	},
}
