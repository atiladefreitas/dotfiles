return {
	"sschleemilch/slimline.nvim",
	opts = {
		bold = true,
		verbose_mode = false,
	},
}
