return {
	{
		"NvChad/volt",
		lazy = true,
	},
	{
		"NvChad/minty",
		lazy = true,
		config = function()
			-- No need for `setup` function, directly use the module as needed
		end,
	},
}
